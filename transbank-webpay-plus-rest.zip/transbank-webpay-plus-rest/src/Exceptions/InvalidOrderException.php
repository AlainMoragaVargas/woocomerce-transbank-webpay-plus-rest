<?php

namespace Transbank\WooCommerce\WebpayRest\Exceptions;

class InvalidOrderException extends \Exception
{

}
