<?php

namespace Transbank\WooCommerce\WebpayRest\Exceptions;

class TokenNotFoundOnDatabaseException extends \Exception
{

}
